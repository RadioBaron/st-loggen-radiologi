import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { useLocalState, STORAGE_KEYS } from "@/lib/storage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export type ScheduleEntry = {
  id: string;
  department: string;
  startMonth: string; // YYYY-MM
  months: number;
  notes?: string;
};

const GOAL_MONTHS = 60;

const DEFAULT_DEPARTMENTS = [
  "Thorax",
  "Abdomen",
  "Neuro",
  "Muskuloskeletal",
  "Mammografi",
  "Akutradiologi",
  "Intervention",
  "Barnradiologi",
  "Ultraljud",
  "Nuklearmedicin",
  "Forskning",
  "Sidotjänstgöring",
  "Övrigt",
];

export const Route = createFileRoute("/schema")({
  head: () => ({
    meta: [
      { title: "Långtidsschema – ST-loggen Radiologi" },
      { name: "description", content: "Planera och följ dina placeringar under ST." },
    ],
  }),
  component: SchedulePage,
});

function genId() {
  return Math.random().toString(36).slice(2, 10);
}

function formatMonth(ym: string) {
  if (!/^\d{4}-\d{2}$/.test(ym)) return ym;
  const [y, m] = ym.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString("sv-SE", {
    year: "numeric",
    month: "short",
  });
}

function addMonths(ym: string, n: number) {
  const [y, m] = ym.split("-").map(Number);
  const d = new Date(y, m - 1 + n, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function SchedulePage() {
  const [entries, setEntries] = useLocalState<ScheduleEntry[]>(
    STORAGE_KEYS.schedule,
    [],
  );
  const [draft, setDraft] = useState<Omit<ScheduleEntry, "id">>({
    department: DEFAULT_DEPARTMENTS[0],
    startMonth: new Date().toISOString().slice(0, 7),
    months: 3,
    notes: "",
  });

  const sorted = useMemo(
    () => [...entries].sort((a, b) => a.startMonth.localeCompare(b.startMonth)),
    [entries],
  );

  const totalMonths = entries.reduce((s, e) => s + (e.months || 0), 0);
  const pct = Math.min(100, Math.round((totalMonths / GOAL_MONTHS) * 100));

  const byDept = useMemo(() => {
    const map = new Map<string, number>();
    for (const e of entries) {
      map.set(e.department, (map.get(e.department) || 0) + (e.months || 0));
    }
    return [...map.entries()].sort((a, b) => b[1] - a[1]);
  }, [entries]);

  const add = () => {
    if (!draft.department || !draft.startMonth || !draft.months) {
      toast.error("Fyll i avdelning, startmånad och antal månader.");
      return;
    }
    setEntries((prev) => [...prev, { id: genId(), ...draft }]);
    toast.success("Placering tillagd");
    setDraft((d) => ({ ...d, notes: "" }));
  };

  const remove = (id: string) => {
    setEntries((prev) => prev.filter((e) => e.id !== id));
  };

  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-10">
      <div className="mb-8">
        <p className="text-sm font-medium uppercase tracking-wide text-primary">
          Tjänstgöring
        </p>
        <h1 className="mt-1 text-4xl font-semibold tracking-tight">
          Långtidsschema
        </h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">
          Lägg in dina placeringar månad för månad. Målet är {GOAL_MONTHS}{" "}
          månaders tjänstgöring.
        </p>
      </div>

      <Card className="mb-8 border-border/60">
        <CardContent className="grid gap-6 p-6 md:grid-cols-[1fr_2fr]">
          <div>
            <p className="font-display text-3xl font-semibold">
              {totalMonths} / {GOAL_MONTHS}
            </p>
            <p className="text-sm text-muted-foreground">månader inlagda</p>
            <Progress value={pct} className="mt-3 h-2" />
            <p className="mt-1 text-sm text-muted-foreground">{pct}%</p>
          </div>
          <div>
            <p className="mb-2 text-sm font-medium">Fördelning per avdelning</p>
            {byDept.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Inga placeringar inlagda ännu.
              </p>
            ) : (
              <ul className="space-y-1.5">
                {byDept.map(([dept, months]) => (
                  <li
                    key={dept}
                    className="flex items-center justify-between text-sm"
                  >
                    <span>{dept}</span>
                    <span className="text-muted-foreground">
                      {months} mån
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="mb-8 border-border/60">
        <CardHeader>
          <CardTitle className="font-display text-xl">
            Lägg till placering
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-[2fr_1fr_1fr_2fr_auto]">
            <div>
              <Label htmlFor="dept">Avdelning</Label>
              <Select
                value={draft.department}
                onValueChange={(v) =>
                  setDraft((d) => ({ ...d, department: v }))
                }
              >
                <SelectTrigger id="dept" className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DEFAULT_DEPARTMENTS.map((d) => (
                    <SelectItem key={d} value={d}>
                      {d}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="start">Startmånad</Label>
              <Input
                id="start"
                type="month"
                value={draft.startMonth}
                onChange={(e) =>
                  setDraft((d) => ({ ...d, startMonth: e.target.value }))
                }
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="months">Antal mån</Label>
              <Input
                id="months"
                type="number"
                min={1}
                max={60}
                value={draft.months}
                onChange={(e) =>
                  setDraft((d) => ({
                    ...d,
                    months: Math.max(1, Number(e.target.value) || 1),
                  }))
                }
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="notes">Anteckning (valfritt)</Label>
              <Input
                id="notes"
                value={draft.notes ?? ""}
                onChange={(e) =>
                  setDraft((d) => ({ ...d, notes: e.target.value }))
                }
                className="mt-1"
                placeholder="t.ex. handledare, fokusområde"
              />
            </div>
            <div className="flex items-end">
              <Button onClick={add} className="w-full md:w-auto">
                <Plus className="mr-1 h-4 w-4" /> Lägg till
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="font-display text-xl">Tidslinje</CardTitle>
        </CardHeader>
        <CardContent>
          {sorted.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              Inga placeringar inlagda ännu. Lägg till din första ovan.
            </p>
          ) : (
            <ul className="divide-y divide-border/60">
              {sorted.map((e) => {
                const endMonth = addMonths(e.startMonth, e.months - 1);
                return (
                  <li
                    key={e.id}
                    className="flex items-center justify-between gap-4 py-4"
                  >
                    <div className="flex-1">
                      <div className="flex items-baseline gap-3">
                        <p className="font-medium text-foreground">
                          {e.department}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {formatMonth(e.startMonth)} – {formatMonth(endMonth)}
                          {" · "}
                          {e.months} mån
                        </p>
                      </div>
                      {e.notes && (
                        <p className="mt-1 text-sm text-muted-foreground">
                          {e.notes}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => remove(e.id)}
                      aria-label="Ta bort"
                    >
                      <Trash2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
