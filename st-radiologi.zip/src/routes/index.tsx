import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { ListChecks, CalendarRange, MessagesSquare, GraduationCap, ArrowRight } from "lucide-react";

import { useLocalState, STORAGE_KEYS } from "@/lib/storage";
import { DEFAULT_MILESTONES } from "@/lib/data/milestones";
import type { ScheduleEntry } from "@/routes/schema";
import type { SupervisionSession } from "@/routes/handledarsamtal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Översikt – ST-loggen Radiologi" },
      { name: "description", content: "Översikt över din ST-progression: månader, delmål och handledarsamtal." },
    ],
  }),
  component: Dashboard,
});

const GOAL_MONTHS = 60;

function Dashboard() {
  const [completed] = useLocalState<Record<string, boolean>>(
    STORAGE_KEYS.milestones,
    {},
  );
  const [schedule] = useLocalState<ScheduleEntry[]>(STORAGE_KEYS.schedule, []);
  const [sessions] = useLocalState<SupervisionSession[]>(
    STORAGE_KEYS.supervision,
    [],
  );

  const totalMilestones = useMemo(
    () => DEFAULT_MILESTONES.reduce((s, c) => s + c.milestones.length, 0),
    [],
  );
  const doneMilestones = useMemo(
    () =>
      DEFAULT_MILESTONES.reduce(
        (s, c) => s + c.milestones.filter((m) => completed[m.id]).length,
        0,
      ),
    [completed],
  );

  const monthsLogged = schedule.reduce((s, e) => s + (e.months || 0), 0);
  const monthsPct = Math.min(100, Math.round((monthsLogged / GOAL_MONTHS) * 100));
  const milestonePct =
    totalMilestones === 0
      ? 0
      : Math.round((doneMilestones / totalMilestones) * 100);

  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-10">
      <div className="mb-10">
        <p className="text-sm font-medium uppercase tracking-wide text-primary">
          Min ST-utbildning
        </p>
        <h1 className="mt-1 text-4xl font-semibold tracking-tight">Översikt</h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">
          Följ din progression mot specialistkompetens. All data sparas lokalt
          på den här enheten — ta backup regelbundet via Inställningar.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="flex items-center justify-between font-display text-xl">
              <span>Tjänstgöring</span>
              <span className="text-sm font-normal text-muted-foreground">
                Mål: {GOAL_MONTHS} mån
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between">
              <div>
                <p className="font-display text-5xl font-semibold">
                  {monthsLogged}
                </p>
                <p className="text-sm text-muted-foreground">av {GOAL_MONTHS} månader</p>
              </div>
              <div className="text-right">
                <p className="font-display text-2xl font-semibold text-primary">
                  {monthsPct}%
                </p>
                <p className="text-xs text-muted-foreground">
                  {GOAL_MONTHS - monthsLogged} mån kvar
                </p>
              </div>
            </div>
            <Progress value={monthsPct} className="mt-4 h-2" />
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="flex items-center justify-between font-display text-xl">
              <span>Delmål</span>
              <span className="text-sm font-normal text-muted-foreground">
                {totalMilestones} totalt
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between">
              <div>
                <p className="font-display text-5xl font-semibold">
                  {doneMilestones}
                </p>
                <p className="text-sm text-muted-foreground">avklarade</p>
              </div>
              <div className="text-right">
                <p className="font-display text-2xl font-semibold text-primary">
                  {milestonePct}%
                </p>
                <p className="text-xs text-muted-foreground">
                  {totalMilestones - doneMilestones} kvar
                </p>
              </div>
            </div>
            <Progress value={milestonePct} className="mt-4 h-2" />
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <QuickLink
          to="/delmal"
          icon={<ListChecks className="h-5 w-5" />}
          title="Delmål"
          description="Bocka av delmål."
        />
        <QuickLink
          to="/kurser"
          icon={<GraduationCap className="h-5 w-5" />}
          title="Kurser"
          description="Logga kurser och poäng."
        />
        <QuickLink
          to="/schema"
          icon={<CalendarRange className="h-5 w-5" />}
          title="Långtidsschema"
          description="Placeringar per månad."
        />
        <QuickLink
          to="/handledarsamtal"
          icon={<MessagesSquare className="h-5 w-5" />}
          title="Handledarsamtal"
          description={`${sessions.length} sparade samtal`}
        />
      </div>
    </div>
  );
}

function QuickLink({
  to,
  icon,
  title,
  description,
}: {
  to: string;
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <Link
      to={to}
      className="group flex items-start justify-between rounded-xl border border-border/60 bg-card p-5 transition-all hover:border-primary/40 hover:shadow-sm"
    >
      <div>
        <div className="flex items-center gap-2 text-primary">
          {icon}
          <h3 className="font-display text-lg font-semibold text-foreground">
            {title}
          </h3>
        </div>
        <p className="mt-2 text-sm text-muted-foreground">{description}</p>
      </div>
      <ArrowRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" />
    </Link>
  );
}
