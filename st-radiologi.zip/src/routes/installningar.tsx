import { createFileRoute } from "@tanstack/react-router";
import { useRef } from "react";
import { Download, Upload, Cloud } from "lucide-react";
import { toast } from "sonner";

import { exportAllData, importAllData } from "@/lib/storage";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/installningar")({
  head: () => ({
    meta: [
      { title: "Inställningar – ST-loggen Radiologi" },
      { name: "description", content: "Exportera och importera dina data för backup till molnet." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const fileRef = useRef<HTMLInputElement>(null);

  const onImport = async (file: File) => {
    try {
      await importAllData(file);
      toast.success("Data importerad");
    } catch (e) {
      toast.error((e as Error).message || "Kunde inte läsa filen");
    }
  };

  return (
    <div className="mx-auto w-full max-w-3xl px-6 py-10">
      <div className="mb-8">
        <p className="text-sm font-medium uppercase tracking-wide text-primary">
          Backup &amp; lagring
        </p>
        <h1 className="mt-1 text-4xl font-semibold tracking-tight">
          Inställningar
        </h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">
          All din data lagras lokalt i den här webbläsaren. För att inte
          förlora information bör du regelbundet ta backup genom att exportera
          en fil och spara den på t.ex. Google Drive eller OneDrive.
        </p>
      </div>

      <div className="space-y-4">
        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-display text-lg">
              <Download className="h-5 w-5 text-primary" /> Exportera data
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Skapar en JSON-fil med alla dina delmål, schema och
              handledarsamtal. Ladda upp filen till valfri molntjänst.
            </p>
            <Button onClick={exportAllData}>
              <Download className="mr-1 h-4 w-4" /> Ladda ner backup
            </Button>
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-display text-lg">
              <Upload className="h-5 w-5 text-primary" /> Importera data
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Återställ från en tidigare backup-fil. Befintlig data skrivs över.
            </p>
            <input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onImport(f);
                e.target.value = "";
              }}
            />
            <Button variant="outline" onClick={() => fileRef.current?.click()}>
              <Upload className="mr-1 h-4 w-4" /> Välj backup-fil
            </Button>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-secondary/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-display text-lg">
              <Cloud className="h-5 w-5 text-primary" /> Spara i molnet
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>
              <strong className="text-foreground">Google Drive:</strong> Gå
              till drive.google.com → <em>Ny</em> → <em>Filuppladdning</em> och
              välj din backup-fil.
            </p>
            <p>
              <strong className="text-foreground">OneDrive:</strong> Gå till
              onedrive.live.com → <em>Ladda upp</em> → <em>Filer</em>.
            </p>
            <p className="pt-2">
              Tips: spara en ny backup efter varje handledarsamtal eller minst
              en gång i månaden.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
