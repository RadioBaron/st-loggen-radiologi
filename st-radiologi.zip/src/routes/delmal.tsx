import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";

import { useLocalState, STORAGE_KEYS } from "@/lib/storage";
import { DEFAULT_MILESTONES } from "@/lib/data/milestones";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/delmal")({
  head: () => ({
    meta: [
      { title: "Delmål – ST-loggen Radiologi" },
      { name: "description", content: "Kryssa av delmål under ST-utbildningen." },
    ],
  }),
  component: MilestonesPage,
});

function MilestonesPage() {
  const [completed, setCompleted] = useLocalState<Record<string, boolean>>(
    STORAGE_KEYS.milestones,
    {},
  );

  const toggle = (id: string) =>
    setCompleted((prev) => ({ ...prev, [id]: !prev[id] }));

  const totals = useMemo(() => {
    const total = DEFAULT_MILESTONES.reduce(
      (s, c) => s + c.milestones.length,
      0,
    );
    const done = DEFAULT_MILESTONES.reduce(
      (s, c) => s + c.milestones.filter((m) => completed[m.id]).length,
      0,
    );
    return { total, done, pct: total ? Math.round((done / total) * 100) : 0 };
  }, [completed]);

  return (
    <div className="mx-auto w-full max-w-5xl px-6 py-10">
      <div className="mb-8">
        <p className="text-sm font-medium uppercase tracking-wide text-primary">
          Målbeskrivning
        </p>
        <h1 className="mt-1 text-4xl font-semibold tracking-tight">Delmål</h1>
        <p className="mt-2 max-w-2xl text-muted-foreground">
          Bocka av delmålen efterhand som du uppfyller dem. Listan följer
          strukturen i Socialstyrelsens målbeskrivning för radiologi.
        </p>
      </div>

      <Card className="mb-8 border-border/60">
        <CardContent className="flex items-center justify-between gap-6 p-6">
          <div>
            <p className="font-display text-3xl font-semibold">
              {totals.done} / {totals.total}
            </p>
            <p className="text-sm text-muted-foreground">avklarade delmål</p>
          </div>
          <div className="flex-1 max-w-md">
            <Progress value={totals.pct} className="h-2" />
            <p className="mt-2 text-right text-sm text-muted-foreground">
              {totals.pct}%
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-6">
        {DEFAULT_MILESTONES.map((category) => {
          const catDone = category.milestones.filter(
            (m) => completed[m.id],
          ).length;
          return (
            <Card key={category.id} className="border-border/60">
              <CardHeader>
                <CardTitle className="flex items-baseline justify-between font-display text-xl">
                  <span>{category.title}</span>
                  <span className="text-sm font-normal text-muted-foreground">
                    {catDone} / {category.milestones.length}
                  </span>
                </CardTitle>
                {category.description && (
                  <p className="text-sm text-muted-foreground">
                    {category.description}
                  </p>
                )}
              </CardHeader>
              <CardContent>
                <ul className="divide-y divide-border/60">
                  {category.milestones.map((m) => {
                    const isDone = !!completed[m.id];
                    return (
                      <li key={m.id}>
                        <label className="flex cursor-pointer items-center gap-3 py-3 transition-colors hover:bg-muted/40">
                          <Checkbox
                            checked={isDone}
                            onCheckedChange={() => toggle(m.id)}
                          />
                          <span
                            className={
                              isDone
                                ? "text-muted-foreground line-through"
                                : "text-foreground"
                            }
                          >
                            {m.title}
                          </span>
                        </label>
                      </li>
                    );
                  })}
                </ul>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
